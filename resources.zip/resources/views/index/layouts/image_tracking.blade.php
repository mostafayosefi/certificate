

@if($image_page)
<div class="container">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12 bannerWrap">
            <div class="bannerCont-r">
                <img alt="3 Female students smiling" class="center img-fluid des"
                    src="{{asset($image_page)}}" />
                <img alt="3 Female students smiling mobile image" class="center img-fluid mob"
                    src="{{asset($image_page)}}" />
            </div>
            <div class="bannerCont-l"> 
            </div>
        </div>
    </div>
</div>
</div>




@endif




