<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TestController;
use App\Http\Controllers\Index\IndexController;
use App\Http\Controllers\Auth\AdminAuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('index.home.myindex');
});
 */


Route::name('index.')->group(function () {

    Route::get('/', [IndexController::class, 'index'])->name('home');
    Route::get('/service/{id}', [IndexController::class, 'service'])->name('service');
    Route::get('/faqs', [IndexController::class, 'faqs'])->name('faqs');
    Route::get('/contactus', [IndexController::class, 'contactus'])->name('contactus');
    Route::put('/contactus', [IndexController::class, 'store_contact'])->name('contact.store');
    Route::get('/tracking', [IndexController::class, 'tracking'])->name('tracking');
    Route::put('/tracking', [IndexController::class, 'tracking_result'])->name('tracking.result');

});





Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    return view('dashboard');
})->name('dashboard');


Route::get('/demo', function () {
    return view('admin.faq.create');
});

Route::get('/metronic/demo', function () {
    // return view('admin.faq.create');

    return view('admin.faq.create');
})->name('metronic.dem');



Route::get('/mydashboard', [TestController::class, 'index'])->name('index.dem');



Route::namespace('Auth')->prefix('admin')->group(function () {
    Route::get('/login', [AdminAuthController::class, 'getLogin'])->name('adminLogin');
    Route::post('/login', [AdminAuthController::class, 'postLogin'])->name('adminLoginPost');
    Route::get('/logout', [AdminAuthController::class, 'logout'])->name('adminLogout');
    });




